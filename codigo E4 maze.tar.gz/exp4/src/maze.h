
void setMaze();
void moveLeft();
void moveRight();
void moveUp();
void moveDown();
