#include <stdio.h>

void timer_init();
void timer_start();
void timer_disable();
void frequency_toggle();
void frequency_set(uint16_t f);
