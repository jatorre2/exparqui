#include <stdint.h>
#include "msp430.h"
#include "HAL_LCD.h"

void wait_for_button_and_clear(void);
void test(void);
