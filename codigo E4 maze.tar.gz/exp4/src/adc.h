uint16_t adc_busy();
void adc_start();
void adc_init();
void pot_init();
